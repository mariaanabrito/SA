/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.adafruitconnector;

/**
 *
 * @author JCoelho
 */

import java.util.Properties;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Enumeration;

import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;

public class ArduinoRead implements SerialPortEventListener {
		
    SerialPort serialPort;
    private static final String PORT_NAME = "COM5"; 
    private BufferedReader input;
    private OutputStream output;
    private static final int TIME_OUT = 2000;
    private static final int DATA_RATE = 9600;
    private String topic = "jcoelho/feeds/command";
    private String content;
    private int qos = 2;
    private static String broker = "tcp://io.adafruit.com:1883";
    private static String clientId = "JavaSample";
    private static MemoryPersistence persistence = new MemoryPersistence();
    private static MqttClient sampleClient;
    private int dangerAlert = 10;
    private int safetyAlert = 100;

    public void initialize() {
        CommPortIdentifier portId = null;
        Enumeration portEnum = CommPortIdentifier.getPortIdentifiers();

        while (portEnum.hasMoreElements()) {
            CommPortIdentifier currPortId = (CommPortIdentifier) portEnum.nextElement();
            if (currPortId.getName().equals(PORT_NAME)) {
                portId = currPortId;
                break;
            }
        }
        if (portId == null) {
            System.out.println("Could not find COM port.");
            return;
        }

        try {
            serialPort = (SerialPort) portId.open(this.getClass().getName(), TIME_OUT);
            serialPort.setSerialPortParams(DATA_RATE,
                    SerialPort.DATABITS_8,
                    SerialPort.STOPBITS_1,
                    SerialPort.PARITY_NONE);
            // open the stream
            input = new BufferedReader(new InputStreamReader(serialPort.getInputStream()));
            serialPort.addEventListener(this);
            serialPort.notifyOnDataAvailable(true);
        } catch (Exception e) {
            System.err.println(e.toString());
        }
    }

    public synchronized void close() {
        if (serialPort != null) {
            serialPort.removeEventListener();
            serialPort.close();
        }
    }

    public synchronized void serialEvent(SerialPortEvent oEvent) {
        if (oEvent.getEventType() == SerialPortEvent.DATA_AVAILABLE) {
            try {
                String inputLine = null;

                if (input.ready()) {
                    inputLine = input.readLine();
                    if (inputLine.equals("No flame")) {
                        this.safetyAlert--;
                        if (this.dangerAlert != 10)
                            this.dangerAlert = 10;
                        content = "0";
                    }
                    else {
                        this.dangerAlert--;
                        if (this.safetyAlert != 100)
                            this.safetyAlert = 100;
                        content = "1";
                    }
                    if (this.dangerAlert == 0 || this.safetyAlert == 0){
                        System.out.println("Publishing message: "+content);
                        MqttMessage message = new MqttMessage(content.getBytes());
                        message.setQos(qos);
                        sampleClient.publish(topic, message);
                        System.out.println("Message published");
                        System.out.println(inputLine);
                        this.dangerAlert = 10;
                        this.safetyAlert = 100;
                    }
                }

            } catch (Exception e) {
                if (e instanceof MqttException) {
                    //System.out.println("reason "+e.getReasonCode());
                    System.out.println("msg "+e.getMessage());
                    System.out.println("loc "+e.getLocalizedMessage());
                    System.out.println("cause "+e.getCause());
                    System.out.println("excep "+e);
                    e.printStackTrace(); 
                }
                else System.err.println(e.toString());
            }
        // Ignore all the other eventTypes, but you should consider the other ones.
    }}

    public static void main(String[] args) throws Exception {
        ArduinoRead main = new ArduinoRead();
        sampleClient = new MqttClient(broker, clientId, persistence);
        MqttConnectOptions connOpts = new MqttConnectOptions();
        connOpts.setCleanSession(true);
        connOpts.setUserName("jcoelho");
        connOpts.setPassword("53818ef023f64a55bbd64375fd61722c".toCharArray());
        connOpts.setSSLProperties(new Properties());
        System.out.println("Connecting to broker: "+broker);
        sampleClient.connect(connOpts);
        System.out.println("Connected");
        
        main.initialize();
        Thread t = new Thread() {
            public void run() {
                //the following line will keep this app alive for 1000    seconds,
                //waiting for events to occur and responding to them    (printing incoming messages to console).
                try {Thread.sleep(1000000);} catch (InterruptedException ie) {}
            }
        };
        t.start();
        System.out.println("Started");
    }
}
